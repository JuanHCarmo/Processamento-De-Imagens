%Foram usados os filtros notch, para eliminar o ruído simétrico nos quadrantes do espectro de frequência, e passa alta, para eliminar a distorção de sombra.

pkg load image

D0 = 100; % Define um valor para o parâmetro D0 (usado nos filtros)

entrada = imread("imagem.jpg");

% Obtém as dimensões da imagem
[M, N, ~] = size(entrada);
P = M * 2; % Dobra o tamanho da imagem em altura
Q = N * 2; % Dobra o tamanho da imagem em largura

% Criação das matrizes de coordenadas U e V para o espaço de frequência
[U, V] = meshgrid(0:Q-1, 0:P-1);

% Centro do espectro (após fftshift, a frequência zero fica no meio da matriz P x Q).
cx = Q / 2;
cy = P / 2;

% Calcula a distância para o ponto central (cx, cy) no espaço de frequência
DA = sqrt((U - cx).^2 + (V - cy).^2);

% Criação de um filtro gaussiano passa-alta
HA = 1 - (exp(-(DA.^2) / (2 * (1^2))));

% Cálculo de diversas distâncias para centros de filtros notch

D1Q1N = sqrt((U - cx - 537).^2 + (V - cy - 111).^2);
D1Q1S = sqrt((U - cx + 537).^2 + (V - cy + 111).^2);

D1Q2N = sqrt((U - cx - 1119).^2 + (V - cy - 202).^2);
D1Q2S = sqrt((U - cx + 1119).^2 + (V - cy + 202).^2);

D1Q3N = sqrt((U - cx - 200).^2 + (V - cy - 600).^2);
D1Q3S = sqrt((U - cx + 200).^2 + (V - cy + 600).^2);

D1Q4N = sqrt((U - cx - 681).^2 + (V - cy - 394).^2);
D1Q4S = sqrt((U - cx + 681).^2 + (V - cy + 394).^2);

D1Q5N = sqrt((U - cx - 0).^2 + (V - cy - 338).^2);
D1Q5S = sqrt((U - cx + 0).^2 + (V - cy + 338).^2);

D2Q1N = sqrt((U - cx - 531).^2 + (V - cy + 224).^2);
D2Q1S = sqrt((U - cx + 531).^2 + (V - cy - 224).^2);

D2Q2N = sqrt((U - cx - 1066).^2 + (V - cy + 110).^2);
D2Q2S = sqrt((U - cx + 1066).^2 + (V - cy - 110).^2);

D2Q3N = sqrt((U - cx - 199).^2 + (V - cy + 302).^2);
D2Q3S = sqrt((U - cx + 199).^2 + (V - cy - 302).^2);

D2Q4N = sqrt((U - cx - 481).^2 + (V - cy + 203).^2);
D2Q4S = sqrt((U - cx + 481).^2 + (V - cy - 203).^2);

D2Q5N = sqrt((U - cx - 384).^2 + (V - cy + 492).^2);
D2Q5S = sqrt((U - cx + 384).^2 + (V - cy - 492).^2);

% Criação dos filtros gaussianos notch baseados nas distâncias calculadas
H1 = 1 - (exp(-(D1Q1N.^2) / (2 * (D0^2))));
H2 = 1 - (exp(-(D1Q1S.^2) / (2 * (D0^2))));
H3 = 1 - (exp(-(D1Q2N.^2) / (2 * (D0^2))));
H4 = 1 - (exp(-(D1Q2S.^2) / (2 * (D0^2))));
H5 = 1 - (exp(-(D1Q3N.^2) / (2 * (D0^2))));
H6 = 1 - (exp(-(D1Q3S.^2) / (2 * (D0^2))));
H7 = 1 - (exp(-(D1Q4N.^2) / (2 * (D0^2))));
H8 = 1 - (exp(-(D1Q4S.^2) / (2 * (D0^2))));
H9 = 1 - (exp(-(D1Q5N.^2) / (2 * (D0^2))));
H10 = 1 - (exp(-(D1Q5S.^2) / (2 * (D0^2))));
H11 = 1 - (exp(-(D2Q1N.^2) / (2 * (D0^2))));
H12 = 1 - (exp(-(D2Q1S.^2) / (2 * (D0^2))));
H13 = 1 - (exp(-(D2Q2N.^2) / (2 * (D0^2))));
H14 = 1 - (exp(-(D2Q2S.^2) / (2 * (D0^2))));
H15 = 1 - (exp(-(D2Q3N.^2) / (2 * (D0^2))));
H16 = 1 - (exp(-(D2Q3S.^2) / (2 * (D0^2))));
H17 = 1 - (exp(-(D2Q4N.^2) / (2 * (D0^2))));
H18 = 1 - (exp(-(D2Q4S.^2) / (2 * (D0^2))));
H19 = 1 - (exp(-(D2Q5N.^2) / (2 * (D0^2))));
H20 = 1 - (exp(-(D2Q5S.^2) / (2 * (D0^2))));

% Multiplicação dos filtros
H = H1 .* H2 .* H3 .* H4 .* H5 .* H6 .* H7 .* H8 .* H9 .* H10 .* H11 .* H12 .* H13 .* H14 .* H15 .* H16 .* H17 .* H18 .* H19 .* H20;

% Aplicação do filtro ao espaço de frequência
FB = ones(P, Q) .* HA .* H;

imshow(FB);

% Separação dos canais de cor
I1 = im2double(entrada);
R = I1(:, :, 1);
G = I1(:, :, 2);
B = I1(:, :, 3);

% Aplicação do filtro nos canais R, G e B
R9 = im2uint8(mat2gray(real(ifft2(ifftshift(fftshift(fft2(R, P, Q)) .* FB)))(1:M, 1:N)));
G9 = im2uint8(mat2gray(real(ifft2(ifftshift(fftshift(fft2(G, P, Q)) .* FB)))(1:M, 1:N)));
B9 = im2uint8(mat2gray(real(ifft2(ifftshift(fftshift(fft2(B, P, Q)) .* FB)))(1:M, 1:N)));

% Criação da imagem filtrada
I10 = cat(3, R9, G9, B9);

I11 = zeros(size(I10), 'uint8');
for c = 1:3
    canal = I10(:, :, c);
    limites = stretchlim(canal, [0.01 0.99]);
    I11(:, :, c) = imadjust(canal, limites, []);
end

% Geração da imagem final e das visualizações de espectro
%prototipo = cat(1, cat(2, imresize(entrada, 2), imresize(I10, 2)), cat(2, uint8(255 * mat2gray(log(1 + abs(fftshift(fft2(I1)))))), uint8(255 * mat2gray(log(1 + abs(fftshift(fft2(I10))))))));

imshow(I11);

% Salva as imagens geradas com timestamps
%imwrite(prototipo, sprintf("prototipo %s.png", strftime("%Y%m%d_%H%M%S", localtime(time()))));
imwrite(I11, sprintf("final %s.png", strftime("%Y%m%d_%H%M%S", localtime(time()))));

